//
//  Mockplus.h
//  Mockplus
//
//  Created by Abel-zwx on 2023/4/15.
//

#import <Foundation/Foundation.h>

//! Project version number for Mockplus.
FOUNDATION_EXPORT double MockplusVersionNumber;

//! Project version string for Mockplus.
FOUNDATION_EXPORT const unsigned char MockplusVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Mockplus/PublicHeader.h>


